# Quiz Interativo — Projeto 04

Aplicativo Android educacional de perguntas e respostas, desenvolvido para a disciplina de **Desenvolvimento Mobile**.
O participante escolhe uma categoria de Tecnologia da Informação, responde questões de múltipla escolha com cinco
alternativas, recebe o feedback de cada resposta e, no final, vê sua pontuação.

## Funcionalidades

- **Tela inicial com 5 categorias:** Programação, Banco de Dados, Redes de Computadores, Segurança da Informação e Desenvolvimento Mobile, com 6 perguntas cada.
- **Questões com cinco alternativas (A a E)**, selecionadas por `RadioButton`.
- **Confirmação de resposta:** o botão "Confirmar resposta" só fica habilitado depois que uma alternativa é escolhida.
- **Resposta travada:** depois de confirmada, a resposta não pode ser alterada nem contada duas vezes.
- **Feedback imediato:** mostra se acertou ou errou e destaca a alternativa correta (verde) e a escolhida errada (vermelho).
- **Progresso:** texto "Questão X de Y" e barra de progresso (`LinearProgressIndicator`).
- **Tela de resultado:** quantidade de acertos e de erros, porcentagem de aproveitamento e uma mensagem de acordo com o desempenho.
- **Reiniciar questionário** ou **escolher outra categoria**.
- **O estado não se perde ao girar a tela.**
- Tema **claro e escuro** (segue o sistema) e cores dinâmicas no Android 12+.
- Layout com rolagem e largura máxima: funciona em celulares pequenos, na horizontal e em tablets.

## Tecnologias

- **Kotlin**
- **Jetpack Compose** + **Material Design 3**
- Conceitos usados: `@Composable`, `Column`, `Row`, `RadioButton`, `Button`, `data class`, `List`, `enum class`,
  `remember`/`rememberSaveable`, `mutableStateOf`, `Scaffold`, `TopAppBar`, `Card`, `AlertDialog`
- **JUnit 4** para os testes unitários
- Android Gradle Plugin 9.1.1 · Gradle 9.3.1 · minSdk 24 · compileSdk/targetSdk 36

## Estrutura de pastas

```
app/src/main/java/com/example/pdm4/
├── MainActivity.kt            → Activity única; chama setContent { PDM4Theme { QuizApp() } }
├── model/                     → classes de dados
│   ├── Categoria.kt           → enum com as 5 categorias
│   ├── Pergunta.kt            → enunciado, 5 alternativas e índice da correta
│   └── Resultado.kt           → acertos, erros, total e porcentagem
├── data/
│   └── BancoDePerguntas.kt    → lista fixa de perguntas de cada categoria
├── logic/
│   └── EstadoQuiz.kt          → REGRAS DO QUIZ (Kotlin puro, sem Compose)
└── ui/
    ├── QuizApp.kt             → guarda o estado (rememberSaveable) e escolhe a tela
    ├── screens/               → TelaCategorias, TelaPergunta, TelaResultado
    ├── components/            → AlternativaItem, BarraProgresso, FeedbackResposta,
    │                            CartaoCategoria, ConteudoRolavel
    └── theme/                 → cores, tipografia e tema claro/escuro

app/src/test/java/com/example/pdm4/logic/
└── EstadoQuizTest.kt          → testes unitários das regras de negócio
```

### Separação entre interface e regras de negócio

Toda a lógica (respostas, bloqueio de resposta dupla, progresso e pontuação) fica em `logic/EstadoQuiz.kt`,
uma `data class` **imutável** que não usa nenhuma classe do Compose. Cada ação (`selecionar`, `confirmar`,
`avancar`, `reiniciar`) devolve um **novo** estado. As telas só exibem o estado e avisam quando o usuário toca em algo.

### Gerenciamento de estado

Em `QuizApp.kt`, o estado é guardado com
`rememberSaveable(stateSaver = EstadoQuizSaver) { mutableStateOf(EstadoQuiz()) }`:

- `mutableStateOf` faz o Compose redesenhar a tela sempre que o estado muda;
- `rememberSaveable` preserva o estado quando a tela gira e também quando o Android encerra o app em segundo plano;
- o `EstadoQuizSaver` converte o estado em tipos simples (`String`, `Int`, `IntArray`, `Boolean`) para que ele possa ser salvo.

Escolhi `rememberSaveable` em vez de `ViewModel` porque usa os conceitos vistos na disciplina, não exige dependências extras
e, para um app com um único fluxo, é mais simples.

## Como executar

1. Abra a pasta do projeto no **Android Studio**.
2. Aguarde a sincronização do Gradle.
3. Escolha um emulador ou um celular com a depuração USB ativada e clique em **Run ▶**.

Pelo terminal, na raiz do projeto:

```bash
./gradlew assembleDebug   # gera o APK em app/build/outputs/apk/debug/
./gradlew test            # executa os testes unitários
```

> **Atenção (Windows):** o Android Gradle Plugin não funciona bem com acentos no caminho da pasta, como em "Informática".
> O `gradle.properties` tem `android.overridePathCheck=true` para permitir o build, mas os **testes unitários só rodam**
> se o projeto estiver numa pasta **sem acentos**, por exemplo `C:\Projetos\PDM4`.

## Capturas de tela

| Categorias | Pergunta | Feedback | Resultado |
|:---:|:---:|:---:|:---:|
| ![Tela de categorias](docs/categorias.png) | ![Tela de pergunta](docs/pergunta.png) | ![Feedback da resposta](docs/feedback.png) | ![Tela de resultado](docs/resultado.png) |

| Modo escuro | Tela na horizontal |
|:---:|:---:|
| ![Modo escuro](docs/escuro.png) | ![Horizontal](docs/horizontal.png) |

> Para adicionar as imagens, crie a pasta `docs/` na raiz do projeto e salve as capturas com os nomes acima.

## Autoria

Projeto desenvolvido por [seu nome] para a disciplina de Desenvolvimento Mobile — Univap, 2026.
