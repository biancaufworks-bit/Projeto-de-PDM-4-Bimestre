package com.example.pdm4.model

/**
 * Representa uma questão do quiz.
 *
 * @property enunciado texto da pergunta.
 * @property alternativas lista com exatamente CINCO alternativas.
 * @property indiceCorreto posição (0 a 4) da alternativa correta dentro de [alternativas].
 */
data class Pergunta(
    val enunciado: String,
    val alternativas: List<String>,
    val indiceCorreto: Int
) {
    init {
        // Garante, já na criação do objeto, que toda pergunta segue a regra do projeto.
        require(alternativas.size == QUANTIDADE_ALTERNATIVAS) {
            "A pergunta \"$enunciado\" deve ter $QUANTIDADE_ALTERNATIVAS alternativas."
        }
        require(indiceCorreto in alternativas.indices) {
            "Índice correto inválido na pergunta \"$enunciado\"."
        }
    }

    /** Texto da alternativa correta (usado no feedback). */
    val alternativaCorreta: String get() = alternativas[indiceCorreto]

    companion object {
        const val QUANTIDADE_ALTERNATIVAS = 5
    }
}
