package com.example.pdm4.ui.screens

import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.example.pdm4.data.BancoDePerguntas
import com.example.pdm4.model.Categoria
import com.example.pdm4.ui.components.CartaoCategoria
import com.example.pdm4.ui.components.ConteudoRolavel
import com.example.pdm4.ui.theme.PDM4Theme

/**
 * Tela inicial: lista as categorias. Ao tocar em uma, o quiz começa.
 *
 * A tela NÃO guarda estado nem conhece as regras do quiz. Ela só avisa quem a chamou,
 * pelo parâmetro [onEscolherCategoria], que uma categoria foi tocada.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TelaCategorias(onEscolherCategoria: (Categoria) -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Quiz Interativo") }) }
    ) { padding ->
        ConteudoRolavel(paddingExterno = padding) {
            Text(
                text = "Escolha uma categoria",
                style = MaterialTheme.typography.headlineSmall
            )
            Text(
                text = "Cada pergunta tem cinco alternativas. Depois de confirmar, a resposta não pode ser alterada.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            // Categoria.entries = lista com todos os valores do enum
            Categoria.entries.forEach { categoria ->
                CartaoCategoria(
                    categoria = categoria,
                    quantidadePerguntas = BancoDePerguntas.perguntasDa(categoria).size,
                    onClick = { onEscolherCategoria(categoria) }
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun TelaCategoriasPreview() {
    PDM4Theme(dynamicColor = false) { TelaCategorias(onEscolherCategoria = {}) }
}
