package com.example.pdm4

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.pdm4.ui.QuizApp
import com.example.pdm4.ui.theme.PDM4Theme

/**
 * Única Activity do app. Em vez de carregar um layout XML (setContentView),
 * ela desenha a interface com Jetpack Compose usando setContent { ... }.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge() // desenha atrás das barras do sistema (o Scaffold cuida dos espaçamentos)
        setContent {
            PDM4Theme {
                QuizApp()
            }
        }
    }
}
