package com.example.pdm4.logic

import com.example.pdm4.model.Categoria
import com.example.pdm4.model.Pergunta
import com.example.pdm4.model.Resultado

/**
 * REGRAS DE NEGÓCIO DO QUIZ (Kotlin puro, sem nenhuma dependência do Compose).
 *
 * Esta data class guarda TUDO o que o quiz precisa saber em um determinado momento.
 * Ela é IMUTÁVEL: nenhuma função altera o objeto atual. Cada ação, como confirmar ou avançar,
 * devolve um NOVO EstadoQuiz com as mudanças, usando copy().
 * Vantagens:
 *  - a interface só precisa trocar o estado antigo pelo novo, e o Compose redesenha a tela;
 *  - é fácil de testar com JUnit (entra um estado, sai outro);
 *  - ações inválidas (por exemplo, responder duas vezes) simplesmente devolvem o MESMO estado.
 *
 * @property categoria categoria escolhida (null = ainda está na tela de categorias).
 * @property perguntas perguntas do quiz atual.
 * @property indiceAtual posição da questão exibida (começa em 0).
 * @property selecionada alternativa marcada no RadioButton e ainda não confirmada (null = nenhuma).
 * @property respostas resposta CONFIRMADA de cada questão (null = ainda não respondida).
 *                     A lista tem uma posição por pergunta, então cada questão só pode ser
 *                     contada UMA vez.
 * @property finalizado true quando o participante passou da última questão (tela de resultado).
 */
data class EstadoQuiz(
    val categoria: Categoria? = null,
    val perguntas: List<Pergunta> = emptyList(),
    val indiceAtual: Int = 0,
    val selecionada: Int? = null,
    val respostas: List<Int?> = emptyList(),
    val finalizado: Boolean = false
) {

    // ------------------------------------------------------------------
    // Informações derivadas (calculadas a partir dos dados acima)
    // ------------------------------------------------------------------

    /** true quando um quiz foi iniciado (já existe categoria e perguntas). */
    val emAndamento: Boolean get() = categoria != null && perguntas.isNotEmpty()

    /** Pergunta exibida no momento (null se o quiz não começou). */
    val perguntaAtual: Pergunta? get() = perguntas.getOrNull(indiceAtual)

    /** Número da questão para exibir ao usuário (1, 2, 3...). */
    val numeroQuestao: Int get() = indiceAtual + 1

    val totalQuestoes: Int get() = perguntas.size

    /** Resposta já confirmada na questão atual (null = ainda não confirmou). */
    val respostaConfirmada: Int? get() = respostas.getOrNull(indiceAtual)

    /** A questão atual já foi respondida? Se sim, ela está TRAVADA. */
    val questaoAtualRespondida: Boolean get() = respostaConfirmada != null

    /** Acertou a questão atual? (null enquanto não confirmar) */
    val acertouQuestaoAtual: Boolean?
        get() {
            val resposta = respostaConfirmada ?: return null
            return resposta == perguntaAtual?.indiceCorreto
        }

    /** O botão "Confirmar" só fica habilitado com uma alternativa marcada e a questão ainda aberta. */
    val podeConfirmar: Boolean get() = !finalizado && selecionada != null && !questaoAtualRespondida

    /** O botão "Próxima" só fica habilitado depois que a resposta foi confirmada. */
    val podeAvancar: Boolean get() = !finalizado && questaoAtualRespondida

    val ehUltimaQuestao: Boolean get() = indiceAtual == perguntas.lastIndex

    /** Quantas questões já foram respondidas. */
    val quantidadeRespondidas: Int get() = respostas.count { it != null }

    /** Progresso de 0.0 a 1.0 para o LinearProgressIndicator. */
    val progresso: Float
        get() = if (totalQuestoes == 0) 0f else quantidadeRespondidas.toFloat() / totalQuestoes

    // ------------------------------------------------------------------
    // Ações (cada uma devolve um NOVO estado)
    // ------------------------------------------------------------------

    /** Marca uma alternativa. É ignorada se a questão já foi confirmada (resposta travada). */
    fun selecionar(indiceAlternativa: Int): EstadoQuiz {
        val pergunta = perguntaAtual ?: return this
        if (finalizado || questaoAtualRespondida) return this // bloqueio: não pode mudar a resposta
        if (indiceAlternativa !in pergunta.alternativas.indices) return this
        return copy(selecionada = indiceAlternativa)
    }

    /**
     * Confirma a alternativa selecionada e TRAVA a questão.
     * Se não houver seleção ou a questão já tiver sido respondida, nada muda.
     * Isso impede que a mesma questão seja contada duas vezes.
     */
    fun confirmar(): EstadoQuiz {
        if (!podeConfirmar) return this
        val novasRespostas = respostas.toMutableList()
        novasRespostas[indiceAtual] = selecionada
        return copy(respostas = novasRespostas)
    }

    /** Vai para a próxima questão ou, se for a última, finaliza o quiz. */
    fun avancar(): EstadoQuiz {
        if (!podeAvancar) return this
        return if (ehUltimaQuestao) {
            copy(finalizado = true)
        } else {
            copy(indiceAtual = indiceAtual + 1, selecionada = null)
        }
    }

    /** Recomeça o MESMO quiz (mesma categoria), zerando respostas e pontuação. */
    fun reiniciar(): EstadoQuiz {
        val cat = categoria ?: return EstadoQuiz()
        return iniciar(cat, perguntas)
    }

    /** Volta para a tela de escolha de categorias. */
    fun voltarParaCategorias(): EstadoQuiz = EstadoQuiz()

    /** Calcula a pontuação: acertos, erros e porcentagem. */
    fun calcularResultado(): Resultado {
        var acertos = 0
        var erros = 0
        perguntas.forEachIndexed { i, pergunta ->
            val resposta = respostas.getOrNull(i) ?: return@forEachIndexed // não respondida: não conta
            if (resposta == pergunta.indiceCorreto) acertos++ else erros++
        }
        return Resultado(acertos = acertos, erros = erros)
    }

    companion object {
        /** Cria o estado inicial de um quiz para a categoria escolhida. */
        fun iniciar(categoria: Categoria, perguntas: List<Pergunta>): EstadoQuiz =
            EstadoQuiz(
                categoria = categoria,
                perguntas = perguntas,
                respostas = List(perguntas.size) { null } // nenhuma questão respondida ainda
            )
    }
}
