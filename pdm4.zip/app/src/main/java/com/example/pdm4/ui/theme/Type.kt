package com.example.pdm4.ui.theme

import androidx.compose.material3.Typography

// Usamos a tipografia padrão do Material Design 3.
val Typography = Typography()
