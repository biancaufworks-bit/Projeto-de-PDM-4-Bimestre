package com.example.pdm4.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.pdm4.data.BancoDePerguntas
import com.example.pdm4.logic.EstadoQuiz
import com.example.pdm4.model.Categoria
import com.example.pdm4.ui.components.AlternativaItem
import com.example.pdm4.ui.components.BarraProgresso
import com.example.pdm4.ui.components.ConteudoRolavel
import com.example.pdm4.ui.components.DestaqueAlternativa
import com.example.pdm4.ui.components.FeedbackResposta
import com.example.pdm4.ui.theme.PDM4Theme

/**
 * Tela de uma questão. Funciona em duas etapas:
 *  1. o usuário escolhe uma alternativa e toca em "Confirmar resposta"
 *     (o botão só é habilitado depois que uma alternativa foi marcada);
 *  2. a resposta fica TRAVADA, o app mostra se acertou ou errou e destaca a correta.
 *     Só então aparece o botão "Próxima questão" (ou "Ver resultado", na última).
 *
 * A tela só LÊ o [estado] e chama as funções recebidas. Quem altera o estado é o QuizApp.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TelaPergunta(
    estado: EstadoQuiz,
    onSelecionar: (Int) -> Unit,
    onConfirmar: () -> Unit,
    onAvancar: () -> Unit,
    onSair: () -> Unit
) {
    val pergunta = estado.perguntaAtual ?: return

    // Estado local só da interface: o diálogo "Sair do quiz?" está aberto?
    // rememberSaveable mantém o diálogo aberto mesmo se a tela girar.
    var mostrarDialogoSair by rememberSaveable { mutableStateOf(false) }

    // O botão "voltar" do celular também pede confirmação antes de sair
    BackHandler { mostrarDialogoSair = true }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(estado.categoria?.titulo ?: "Quiz") },
                actions = { TextButton(onClick = { mostrarDialogoSair = true }) { Text("Sair") } }
            )
        }
    ) { padding ->
        ConteudoRolavel(paddingExterno = padding) {
            BarraProgresso(
                numeroQuestao = estado.numeroQuestao,
                totalQuestoes = estado.totalQuestoes,
                progresso = estado.progresso
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = pergunta.enunciado,
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.padding(16.dp)
                )
            }

            val respondida = estado.questaoAtualRespondida
            // Depois de confirmar, o RadioButton marcado é o da resposta confirmada
            val marcada = estado.respostaConfirmada ?: estado.selecionada

            pergunta.alternativas.forEachIndexed { indice, texto ->
                val destaque = when {
                    !respondida -> DestaqueAlternativa.NENHUM
                    indice == pergunta.indiceCorreto -> DestaqueAlternativa.CORRETA
                    indice == marcada -> DestaqueAlternativa.ERRADA
                    else -> DestaqueAlternativa.NENHUM
                }
                AlternativaItem(
                    letra = 'A' + indice,
                    texto = texto,
                    selecionado = indice == marcada,
                    habilitado = !respondida, // trava as alternativas depois da confirmação
                    destaque = destaque,
                    onClick = { onSelecionar(indice) }
                )
            }

            // Feedback de acerto/erro, exibido apenas depois da confirmação
            estado.acertouQuestaoAtual?.let { acertou ->
                FeedbackResposta(
                    acertou = acertou,
                    letraCorreta = 'A' + pergunta.indiceCorreto,
                    textoCorreto = pergunta.alternativaCorreta
                )
            }

            Spacer(Modifier.height(4.dp))

            if (!respondida) {
                Button(
                    onClick = onConfirmar,
                    enabled = estado.podeConfirmar,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Confirmar resposta") }
            } else {
                Button(
                    onClick = onAvancar,
                    enabled = estado.podeAvancar,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (estado.ehUltimaQuestao) "Ver resultado" else "Próxima questão") }
            }
        }
    }

    if (mostrarDialogoSair) {
        AlertDialog(
            onDismissRequest = { mostrarDialogoSair = false },
            title = { Text("Sair do quiz?") },
            text = { Text("Seu progresso nesta categoria será perdido.") },
            confirmButton = {
                TextButton(onClick = {
                    mostrarDialogoSair = false
                    onSair()
                }) { Text("Sair") }
            },
            dismissButton = {
                TextButton(onClick = { mostrarDialogoSair = false }) { Text("Continuar") }
            }
        )
    }
}

@Preview(showBackground = true)
@Composable
private fun TelaPerguntaPreview() {
    val estado = EstadoQuiz
        .iniciar(Categoria.MOBILE, BancoDePerguntas.perguntasDa(Categoria.MOBILE))
        .selecionar(0)
        .confirmar()
    PDM4Theme(dynamicColor = false) {
        TelaPergunta(estado = estado, onSelecionar = {}, onConfirmar = {}, onAvancar = {}, onSair = {})
    }
}
