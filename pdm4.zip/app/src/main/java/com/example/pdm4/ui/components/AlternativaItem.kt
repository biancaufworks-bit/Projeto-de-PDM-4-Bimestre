package com.example.pdm4.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.pdm4.ui.theme.LocalCoresQuiz

/** Como uma alternativa deve aparecer depois que o usuário confirma a resposta. */
enum class DestaqueAlternativa { NENHUM, CORRETA, ERRADA }

/**
 * Uma alternativa da questão: RadioButton + letra + texto.
 *
 * A linha inteira é clicável (Modifier.selectable), não só o círculo, o que facilita o toque.
 * Depois da confirmação, [habilitado] = false trava a escolha, e [destaque] pinta a
 * alternativa correta de verde e a escolhida errada de vermelho.
 */
@Composable
fun AlternativaItem(
    letra: Char,
    texto: String,
    selecionado: Boolean,
    habilitado: Boolean,
    destaque: DestaqueAlternativa,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cores = MaterialTheme.colorScheme
    val coresQuiz = LocalCoresQuiz.current

    // Cor de fundo e da borda conforme o estado da alternativa
    val (fundo, borda) = when (destaque) {
        DestaqueAlternativa.CORRETA -> coresQuiz.acertoContainer to coresQuiz.acerto
        DestaqueAlternativa.ERRADA -> cores.errorContainer to cores.error
        DestaqueAlternativa.NENHUM ->
            if (selecionado) cores.primaryContainer to cores.primary
            else cores.surface to cores.outlineVariant
    }
    // Símbolo extra para não depender só da cor (acessibilidade para daltônicos)
    val sufixo = when (destaque) {
        DestaqueAlternativa.CORRETA -> "  ✓"
        DestaqueAlternativa.ERRADA -> "  ✗"
        DestaqueAlternativa.NENHUM -> ""
    }
    val espessuraBorda = if (destaque != DestaqueAlternativa.NENHUM || selecionado) 2.dp else 1.dp

    Surface(
        shape = MaterialTheme.shapes.medium,
        color = fundo,
        border = BorderStroke(espessuraBorda, borda),
        modifier = modifier
            .fillMaxWidth()
            .selectable(
                selected = selecionado,
                enabled = habilitado,
                role = Role.RadioButton, // leitores de tela anunciam como "botão de opção"
                onClick = onClick
            )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            RadioButton(
                selected = selecionado,
                onClick = null, // o clique é tratado pela linha inteira (selectable acima)
                enabled = habilitado,
                colors = RadioButtonDefaults.colors(
                    disabledSelectedColor = borda,
                    disabledUnselectedColor = cores.onSurfaceVariant
                )
            )
            Text(
                text = "$letra) $texto$sufixo",
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = if (destaque == DestaqueAlternativa.CORRETA) FontWeight.SemiBold else FontWeight.Normal,
                color = cores.onSurface,
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 4.dp)
            )
        }
    }
}
