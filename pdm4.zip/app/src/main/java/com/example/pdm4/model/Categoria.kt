package com.example.pdm4.model

/**
 * Categorias de perguntas disponíveis no quiz.
 *
 * Usamos um enum porque o conjunto de categorias é fixo. Além disso, o [name] de um enum
 * é uma String simples, o que facilita salvar a categoria escolhida com rememberSaveable.
 */
enum class Categoria(val titulo: String, val descricao: String, val emoji: String) {
    PROGRAMACAO("Programação", "Lógica, linguagens e estruturas de dados", "💻"),
    BANCO_DE_DADOS("Banco de Dados", "SQL, modelagem e transações", "🗄️"),
    REDES("Redes de Computadores", "Protocolos, camadas e endereçamento", "🌐"),
    SEGURANCA("Segurança da Informação", "Ataques, criptografia e boas práticas", "🔒"),
    MOBILE("Desenvolvimento Mobile", "Android, Kotlin e Jetpack Compose", "📱")
}
