package com.example.pdm4.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val EsquemaClaro = lightColorScheme(
    primary = Indigo40,
    primaryContainer = IndigoContainer90,
    secondary = Teal40
)

private val EsquemaEscuro = darkColorScheme(
    primary = Indigo80,
    primaryContainer = IndigoContainer30,
    secondary = Teal80
)

/** Cores extras do quiz, que o Material 3 não tem prontas (o "erro" já existe: colorScheme.error). */
@Immutable
data class CoresQuiz(
    val acerto: Color,
    val acertoContainer: Color
)

/** Permite que qualquer tela acesse as cores do quiz com LocalCoresQuiz.current. */
val LocalCoresQuiz = staticCompositionLocalOf {
    CoresQuiz(acerto = VerdeAcertoClaro, acertoContainer = VerdeAcertoContainerClaro)
}

/**
 * Tema do aplicativo. Segue automaticamente o modo claro/escuro do sistema.
 * No Android 12+ usa as "cores dinâmicas", geradas a partir do papel de parede.
 */
@Composable
fun PDM4Theme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> EsquemaEscuro
        else -> EsquemaClaro
    }

    val coresQuiz = if (darkTheme) {
        CoresQuiz(acerto = VerdeAcertoEscuro, acertoContainer = VerdeAcertoContainerEscuro)
    } else {
        CoresQuiz(acerto = VerdeAcertoClaro, acertoContainer = VerdeAcertoContainerClaro)
    }

    CompositionLocalProvider(LocalCoresQuiz provides coresQuiz) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
