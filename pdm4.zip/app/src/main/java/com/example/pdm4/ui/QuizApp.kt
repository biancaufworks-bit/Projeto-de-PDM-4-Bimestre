package com.example.pdm4.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.example.pdm4.data.BancoDePerguntas
import com.example.pdm4.logic.EstadoQuiz
import com.example.pdm4.model.Categoria
import com.example.pdm4.ui.screens.TelaCategorias
import com.example.pdm4.ui.screens.TelaPergunta
import com.example.pdm4.ui.screens.TelaResultado

/**
 * Ponto central da interface: GUARDA o estado do quiz e decide qual tela mostrar.
 *
 * GERENCIAMENTO DE ESTADO
 * - `rememberSaveable { mutableStateOf(...) }` guarda o EstadoQuiz:
 *     • mutableStateOf → quando o valor muda, o Compose redesenha a tela automaticamente;
 *     • rememberSaveable → o valor sobrevive à rotação da tela (a Activity é recriada)
 *       e também quando o Android encerra o app em segundo plano.
 * - Como o EstadoQuiz tem objetos complexos, ensinamos o Compose a salvá-lo com um Saver
 *   (veja [EstadoQuizSaver]), que converte o estado em tipos simples (String, Int, IntArray, Boolean).
 *
 * NAVEGAÇÃO
 * Não usamos biblioteca de navegação. A tela é escolhida a partir do próprio estado:
 *   sem categoria → Categorias | quiz finalizado → Resultado | caso contrário → Pergunta
 */
@Composable
fun QuizApp() {
    var estado by rememberSaveable(stateSaver = EstadoQuizSaver) { mutableStateOf(EstadoQuiz()) }

    val categoria = estado.categoria
    when {
        categoria == null || !estado.emAndamento -> TelaCategorias(
            onEscolherCategoria = { escolhida ->
                estado = EstadoQuiz.iniciar(escolhida, BancoDePerguntas.perguntasDa(escolhida))
            }
        )

        estado.finalizado -> TelaResultado(
            categoria = categoria,
            resultado = estado.calcularResultado(),
            onReiniciar = { estado = estado.reiniciar() },
            onEscolherCategoria = { estado = estado.voltarParaCategorias() }
        )

        // Cada ação chama uma regra da camada "logic" e substitui o estado antigo pelo novo
        else -> TelaPergunta(
            estado = estado,
            onSelecionar = { indice -> estado = estado.selecionar(indice) },
            onConfirmar = { estado = estado.confirmar() },
            onAvancar = { estado = estado.avancar() },
            onSair = { estado = estado.voltarParaCategorias() }
        )
    }
}

/**
 * Ensina o rememberSaveable a salvar e restaurar o [EstadoQuiz] usando só tipos simples.
 *
 * Não salvamos as perguntas, apenas o NOME da categoria. Na restauração, buscamos as perguntas
 * de novo no BancoDePerguntas. Valores "nulos" são gravados como -1, porque IntArray não aceita null.
 */
val EstadoQuizSaver = listSaver<EstadoQuiz, Any>(
    save = { estado ->
        listOf(
            estado.categoria?.name ?: "",                            // 0: categoria (String)
            estado.indiceAtual,                                      // 1: questão atual (Int)
            estado.selecionada ?: -1,                                // 2: alternativa marcada (Int)
            estado.respostas.map { it ?: -1 }.toIntArray(),          // 3: respostas confirmadas (IntArray)
            estado.finalizado                                        // 4: terminou? (Boolean)
        )
    },
    restore = { valores ->
        val nomeCategoria = valores[0] as String
        if (nomeCategoria.isEmpty()) {
            EstadoQuiz() // estava na tela de categorias
        } else {
            val categoria = Categoria.valueOf(nomeCategoria)
            EstadoQuiz(
                categoria = categoria,
                perguntas = BancoDePerguntas.perguntasDa(categoria),
                indiceAtual = valores[1] as Int,
                selecionada = (valores[2] as Int).takeIf { it >= 0 },
                respostas = (valores[3] as IntArray).map { r -> r.takeIf { it >= 0 } },
                finalizado = valores[4] as Boolean
            )
        }
    }
)
