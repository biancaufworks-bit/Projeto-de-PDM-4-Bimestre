package com.example.pdm4.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.pdm4.model.Categoria
import com.example.pdm4.model.Resultado
import com.example.pdm4.ui.components.ConteudoRolavel
import com.example.pdm4.ui.theme.LocalCoresQuiz
import com.example.pdm4.ui.theme.PDM4Theme

/** Tela final: mostra acertos, erros e porcentagem, com opções para reiniciar ou trocar de categoria. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TelaResultado(
    categoria: Categoria,
    resultado: Resultado,
    onReiniciar: () -> Unit,
    onEscolherCategoria: () -> Unit
) {
    // Na tela de resultado, o botão "voltar" leva para a escolha de categorias
    BackHandler(onBack = onEscolherCategoria)

    val coresQuiz = LocalCoresQuiz.current

    // Mensagem de acordo com o desempenho
    val mensagem = when {
        resultado.porcentagem == 100 -> "Perfeito! Você gabaritou! 🏆"
        resultado.porcentagem >= 70 -> "Muito bem! Ótimo desempenho! 🎉"
        resultado.porcentagem >= 50 -> "Bom trabalho! Dá para melhorar. 👍"
        else -> "Continue estudando e tente novamente! 📚"
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Resultado") }) }
    ) { padding ->
        ConteudoRolavel(paddingExterno = padding) {
            Text(
                text = categoria.titulo,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            // Destaque principal: a porcentagem
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    Text(
                        text = "${resultado.porcentagem}%",
                        style = MaterialTheme.typography.displayLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "de aproveitamento",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            // Acertos e erros lado a lado (Row)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                CaixaNumero(
                    rotulo = "Acertos",
                    valor = resultado.acertos,
                    fundo = coresQuiz.acertoContainer,
                    corValor = coresQuiz.acerto,
                    modifier = Modifier.weight(1f)
                )
                CaixaNumero(
                    rotulo = "Erros",
                    valor = resultado.erros,
                    fundo = MaterialTheme.colorScheme.errorContainer,
                    corValor = MaterialTheme.colorScheme.error,
                    modifier = Modifier.weight(1f)
                )
            }

            Text(
                text = "Você acertou ${resultado.acertos} de ${resultado.total} questões.",
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                text = mensagem,
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(4.dp))

            Button(onClick = onReiniciar, modifier = Modifier.fillMaxWidth()) {
                Text("Reiniciar questionário")
            }
            OutlinedButton(onClick = onEscolherCategoria, modifier = Modifier.fillMaxWidth()) {
                Text("Escolher outra categoria")
            }
        }
    }
}

/** Caixinha com um número grande e um rótulo (usada para acertos e erros). */
@Composable
private fun CaixaNumero(
    rotulo: String,
    valor: Int,
    fundo: Color,
    corValor: Color,
    modifier: Modifier = Modifier
) {
    Card(colors = CardDefaults.cardColors(containerColor = fundo), modifier = modifier) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = valor.toString(),
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = corValor
            )
            Text(text = rotulo, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun TelaResultadoPreview() {
    PDM4Theme(dynamicColor = false) {
        TelaResultado(Categoria.REDES, Resultado(acertos = 4, erros = 2), onReiniciar = {}, onEscolherCategoria = {})
    }
}
