package com.example.pdm4.data

import com.example.pdm4.model.Categoria
import com.example.pdm4.model.Pergunta

/**
 * Banco de perguntas do quiz: uma lista fixa no código, organizada por categoria.
 *
 * Fica separado da interface e da lógica. Para adicionar perguntas, basta incluir novos
 * objetos [Pergunta] na lista da categoria desejada.
 * O "indiceCorreto" começa em 0: 0 = primeira alternativa, 4 = quinta alternativa.
 */
object BancoDePerguntas {

    /** Retorna as perguntas da categoria escolhida. */
    fun perguntasDa(categoria: Categoria): List<Pergunta> = when (categoria) {
        Categoria.PROGRAMACAO -> programacao
        Categoria.BANCO_DE_DADOS -> bancoDeDados
        Categoria.REDES -> redes
        Categoria.SEGURANCA -> seguranca
        Categoria.MOBILE -> mobile
    }

    private val programacao = listOf(
        Pergunta(
            enunciado = "Qual estrutura de dados segue o princípio LIFO (Last In, First Out)?",
            alternativas = listOf("Fila", "Pilha", "Lista ligada", "Árvore binária", "Tabela hash"),
            indiceCorreto = 1
        ),
        Pergunta(
            enunciado = "Qual é a complexidade de tempo da busca binária em um vetor ordenado com n elementos?",
            alternativas = listOf("O(1)", "O(n)", "O(n log n)", "O(log n)", "O(n²)"),
            indiceCorreto = 3
        ),
        Pergunta(
            enunciado = "Em Kotlin, qual palavra-chave declara uma variável cujo valor NÃO pode ser reatribuído?",
            alternativas = listOf("var", "const fun", "val", "let", "static"),
            indiceCorreto = 2
        ),
        Pergunta(
            enunciado = "Na Programação Orientada a Objetos, qual conceito permite que uma classe herde atributos e métodos de outra?",
            alternativas = listOf("Herança", "Encapsulamento", "Abstração", "Sobrecarga", "Composição"),
            indiceCorreto = 0
        ),
        Pergunta(
            enunciado = "O que caracteriza uma função recursiva?",
            alternativas = listOf(
                "Ela é executada em paralelo",
                "Ela não recebe parâmetros",
                "Ela sempre retorna um valor booleano",
                "Ela só pode ser usada com vetores",
                "Ela chama a si mesma, direta ou indiretamente"
            ),
            indiceCorreto = 4
        ),
        Pergunta(
            enunciado = "Qual é o resultado da expressão 7 % 3 na maioria das linguagens de programação (como Kotlin, Java e C)?",
            alternativas = listOf("2", "1", "0", "2,33", "21"),
            indiceCorreto = 1
        )
    )

    private val bancoDeDados = listOf(
        Pergunta(
            enunciado = "Qual comando SQL é usado para consultar (ler) dados de uma tabela?",
            alternativas = listOf("INSERT", "UPDATE", "DELETE", "SELECT", "ALTER"),
            indiceCorreto = 3
        ),
        Pergunta(
            enunciado = "O que é uma chave primária (PRIMARY KEY)?",
            alternativas = listOf(
                "Um campo que referencia outra tabela",
                "Um campo ou conjunto de campos que identifica cada registro de forma única",
                "Um índice usado apenas para ordenar resultados",
                "A primeira coluna criada em qualquer tabela",
                "Uma senha de acesso ao banco de dados"
            ),
            indiceCorreto = 1
        ),
        Pergunta(
            enunciado = "Na sigla ACID, que descreve propriedades das transações, o que significa a letra \"A\"?",
            alternativas = listOf("Atomicidade", "Autenticação", "Agregação", "Acessibilidade", "Assincronia"),
            indiceCorreto = 0
        ),
        Pergunta(
            enunciado = "Qual cláusula SQL filtra grupos criados pelo GROUP BY?",
            alternativas = listOf("WHERE", "ORDER BY", "LIMIT", "DISTINCT", "HAVING"),
            indiceCorreto = 4
        ),
        Pergunta(
            enunciado = "Qual tipo de JOIN retorna apenas os registros que possuem correspondência nas duas tabelas?",
            alternativas = listOf("LEFT JOIN", "RIGHT JOIN", "INNER JOIN", "FULL OUTER JOIN", "CROSS JOIN"),
            indiceCorreto = 2
        ),
        Pergunta(
            enunciado = "Qual é o principal objetivo da normalização de um banco de dados relacional?",
            alternativas = listOf(
                "Aumentar a quantidade de tabelas sem critério",
                "Criptografar os dados armazenados",
                "Acelerar a conexão com a internet",
                "Reduzir redundâncias e evitar anomalias de inserção, atualização e exclusão",
                "Converter o banco relacional em NoSQL"
            ),
            indiceCorreto = 3
        )
    )

    private val redes = listOf(
        Pergunta(
            enunciado = "Quantas camadas possui o modelo de referência OSI?",
            alternativas = listOf("4", "5", "6", "7", "8"),
            indiceCorreto = 3
        ),
        Pergunta(
            enunciado = "Qual protocolo é responsável por traduzir nomes de domínio (como www.exemplo.com) em endereços IP?",
            alternativas = listOf("DHCP", "DNS", "FTP", "SMTP", "ARP"),
            indiceCorreto = 1
        ),
        Pergunta(
            enunciado = "Qual é a porta padrão do protocolo HTTPS?",
            alternativas = listOf("443", "80", "21", "25", "8080"),
            indiceCorreto = 0
        ),
        Pergunta(
            enunciado = "Qual é a principal diferença entre os protocolos TCP e UDP?",
            alternativas = listOf(
                "O UDP é orientado à conexão e o TCP não",
                "O TCP funciona apenas em redes locais",
                "O UDP garante a entrega e a ordem dos pacotes",
                "O TCP só transmite áudio e vídeo",
                "O TCP é orientado à conexão e garante a entrega; o UDP não"
            ),
            indiceCorreto = 4
        ),
        Pergunta(
            enunciado = "Quantos bits possui um endereço IPv4?",
            alternativas = listOf("16", "64", "32", "128", "48"),
            indiceCorreto = 2
        ),
        Pergunta(
            enunciado = "Qual protocolo atribui automaticamente endereços IP aos dispositivos de uma rede?",
            alternativas = listOf("DNS", "ICMP", "SNMP", "DHCP", "HTTP"),
            indiceCorreto = 3
        )
    )

    private val seguranca = listOf(
        Pergunta(
            enunciado = "Quais são os três pilares clássicos da segurança da informação (tríade CIA)?",
            alternativas = listOf(
                "Custo, Integração e Agilidade",
                "Confidencialidade, Integridade e Disponibilidade",
                "Criptografia, Identidade e Autorização",
                "Controle, Inspeção e Auditoria",
                "Conectividade, Interoperabilidade e Armazenamento"
            ),
            indiceCorreto = 1
        ),
        Pergunta(
            enunciado = "Que tipo de ataque usa mensagens falsas (e-mails, SMS, sites) para enganar a vítima e roubar dados?",
            alternativas = listOf("Phishing", "Força bruta", "DDoS", "SQL Injection", "Man-in-the-Middle"),
            indiceCorreto = 0
        ),
        Pergunta(
            enunciado = "Na criptografia assimétrica, qual chave é usada para cifrar uma mensagem destinada a alguém?",
            alternativas = listOf(
                "A chave privada do remetente",
                "Uma senha compartilhada por e-mail",
                "A chave privada do destinatário",
                "Nenhuma chave, apenas um hash",
                "A chave pública do destinatário"
            ),
            indiceCorreto = 4
        ),
        Pergunta(
            enunciado = "Qual é a forma mais eficaz de prevenir ataques de SQL Injection?",
            alternativas = listOf(
                "Usar senhas mais longas no banco",
                "Esconder a URL do sistema",
                "Usar consultas parametrizadas (prepared statements)",
                "Desligar o servidor à noite",
                "Trocar o banco de dados por planilhas"
            ),
            indiceCorreto = 2
        ),
        Pergunta(
            enunciado = "O que é autenticação multifator (MFA)?",
            alternativas = listOf(
                "Usar a mesma senha em vários sites",
                "Trocar a senha todo mês",
                "Ter vários usuários na mesma conta",
                "Exigir dois ou mais fatores de verificação diferentes, como senha e código no celular",
                "Fazer login em vários dispositivos ao mesmo tempo"
            ),
            indiceCorreto = 3
        ),
        Pergunta(
            enunciado = "Que tipo de malware criptografa os arquivos da vítima e exige pagamento para liberá-los?",
            alternativas = listOf("Spyware", "Adware", "Ransomware", "Worm", "Keylogger"),
            indiceCorreto = 2
        )
    )

    private val mobile = listOf(
        Pergunta(
            enunciado = "No Android, qual componente representa uma tela com a qual o usuário interage?",
            alternativas = listOf("Service", "Activity", "BroadcastReceiver", "ContentProvider", "Intent"),
            indiceCorreto = 1
        ),
        Pergunta(
            enunciado = "No Jetpack Compose, qual anotação marca uma função que descreve parte da interface?",
            alternativas = listOf("@Override", "@Inject", "@Entity", "@Test", "@Composable"),
            indiceCorreto = 4
        ),
        Pergunta(
            enunciado = "No Jetpack Compose, qual função mantém o estado mesmo após a rotação da tela?",
            alternativas = listOf("rememberSaveable", "remember", "LaunchedEffect", "derivedStateOf", "SideEffect"),
            indiceCorreto = 0
        ),
        Pergunta(
            enunciado = "Qual arquivo declara as Activities, permissões e outras configurações de um app Android?",
            alternativas = listOf("build.gradle.kts", "strings.xml", "AndroidManifest.xml", "settings.gradle.kts", "colors.xml"),
            indiceCorreto = 2
        ),
        Pergunta(
            enunciado = "No ciclo de vida de uma Activity, qual método é chamado primeiro, quando ela é criada?",
            alternativas = listOf("onStart()", "onResume()", "onPause()", "onCreate()", "onDestroy()"),
            indiceCorreto = 3
        ),
        Pergunta(
            enunciado = "No Jetpack Compose, qual layout organiza seus elementos filhos na horizontal, um ao lado do outro?",
            alternativas = listOf("Column", "Row", "Box", "LazyColumn", "Scaffold"),
            indiceCorreto = 1
        )
    )
}
