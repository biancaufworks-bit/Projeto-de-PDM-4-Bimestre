package com.example.pdm4.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Mostra o progresso do participante: "Questão 3 de 6" + barra de progresso.
 * A barra enche conforme as questões são respondidas (com uma pequena animação).
 */
@Composable
fun BarraProgresso(
    numeroQuestao: Int,
    totalQuestoes: Int,
    progresso: Float,
    modifier: Modifier = Modifier
) {
    val progressoAnimado by animateFloatAsState(targetValue = progresso, label = "progresso")

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                text = "Questão $numeroQuestao de $totalQuestoes",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "${(progresso * 100).toInt()}% concluído",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        LinearProgressIndicator(
            progress = { progressoAnimado },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
        )
    }
}
