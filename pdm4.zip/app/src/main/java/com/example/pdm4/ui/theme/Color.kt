package com.example.pdm4.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta base (usada quando as cores dinâmicas do Android 12+ não estão disponíveis)
val Indigo40 = Color(0xFF4F55C9)
val Indigo80 = Color(0xFFBFC2FF)
val IndigoContainer90 = Color(0xFFE0E0FF)
val IndigoContainer30 = Color(0xFF353AAF)
val Teal40 = Color(0xFF006A62)
val Teal80 = Color(0xFF6FD8CB)

// Cores de feedback do quiz: verde para a alternativa correta
val VerdeAcertoClaro = Color(0xFF1B7A3A)
val VerdeAcertoContainerClaro = Color(0xFFC8F2CF)
val VerdeAcertoEscuro = Color(0xFF7FDB95)
val VerdeAcertoContainerEscuro = Color(0xFF0F5226)
