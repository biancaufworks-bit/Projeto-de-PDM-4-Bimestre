package com.example.pdm4.model

import kotlin.math.roundToInt

/**
 * Resumo do desempenho do participante ao final do quiz.
 */
data class Resultado(
    val acertos: Int,
    val erros: Int
) {
    /** Total de questões respondidas. */
    val total: Int get() = acertos + erros

    /** Porcentagem de acertos (0 a 100). Se não houver questões, retorna 0 para evitar divisão por zero. */
    val porcentagem: Int
        get() = if (total == 0) 0 else (acertos * 100.0 / total).roundToInt()
}
