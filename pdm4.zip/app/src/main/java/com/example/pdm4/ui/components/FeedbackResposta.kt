package com.example.pdm4.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.pdm4.ui.theme.LocalCoresQuiz

/**
 * Caixa exibida depois de confirmar a resposta, informando se acertou ou errou.
 * Quando erra, mostra também qual era a alternativa correta.
 */
@Composable
fun FeedbackResposta(
    acertou: Boolean,
    letraCorreta: Char,
    textoCorreto: String,
    modifier: Modifier = Modifier
) {
    val coresQuiz = LocalCoresQuiz.current
    val fundo = if (acertou) coresQuiz.acertoContainer else MaterialTheme.colorScheme.errorContainer
    val corTitulo = if (acertou) coresQuiz.acerto else MaterialTheme.colorScheme.error

    Surface(color = fundo, shape = MaterialTheme.shapes.medium, modifier = modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = if (acertou) "✓ Você acertou!" else "✗ Você errou.",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = corTitulo
            )
            if (!acertou) {
                Text(
                    text = "Resposta correta: $letraCorreta) $textoCorreto",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}
