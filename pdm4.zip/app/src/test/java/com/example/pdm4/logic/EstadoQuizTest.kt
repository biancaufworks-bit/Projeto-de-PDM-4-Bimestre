package com.example.pdm4.logic

import com.example.pdm4.data.BancoDePerguntas
import com.example.pdm4.model.Categoria
import com.example.pdm4.model.Pergunta
import com.example.pdm4.model.Resultado
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Testes das regras de negócio do quiz.
 * Rodam no computador (JVM), sem emulador, porque a lógica não depende do Android/Compose.
 */
class EstadoQuizTest {

    // Perguntas de teste: a correta é sempre a alternativa 0, para facilitar.
    private val perguntas = List(4) { n ->
        Pergunta("Pergunta $n", listOf("A", "B", "C", "D", "E"), indiceCorreto = 0)
    }

    private fun novoQuiz() = EstadoQuiz.iniciar(Categoria.PROGRAMACAO, perguntas)

    /** Responde a questão atual com a alternativa informada e avança. */
    private fun EstadoQuiz.responderEAvancar(alternativa: Int) =
        selecionar(alternativa).confirmar().avancar()

    // ---------------- Acertos, erros e porcentagem ----------------

    @Test
    fun contaAcertosEErrosCorretamente() {
        val fim = novoQuiz()
            .responderEAvancar(0) // acerto
            .responderEAvancar(2) // erro
            .responderEAvancar(0) // acerto
            .responderEAvancar(4) // erro

        assertTrue(fim.finalizado)
        assertEquals(Resultado(acertos = 2, erros = 2), fim.calcularResultado())
    }

    @Test
    fun porcentagemComTodasCorretas() {
        var estado = novoQuiz()
        repeat(4) { estado = estado.responderEAvancar(0) }
        assertEquals(100, estado.calcularResultado().porcentagem)
    }

    @Test
    fun porcentagemComTodasErradas() {
        var estado = novoQuiz()
        repeat(4) { estado = estado.responderEAvancar(1) }
        val resultado = estado.calcularResultado()
        assertEquals(0, resultado.acertos)
        assertEquals(4, resultado.erros)
        assertEquals(0, resultado.porcentagem)
    }

    @Test
    fun porcentagemEhArredondada() {
        assertEquals(67, Resultado(acertos = 2, erros = 1).porcentagem) // 66,67% -> 67%
        assertEquals(33, Resultado(acertos = 1, erros = 2).porcentagem) // 33,33% -> 33%
        assertEquals(50, Resultado(acertos = 3, erros = 3).porcentagem)
    }

    @Test
    fun porcentagemSemQuestoesNaoDividePorZero() {
        assertEquals(0, Resultado(acertos = 0, erros = 0).porcentagem)
    }

    // ---------------- Bloqueio de resposta dupla ----------------

    @Test
    fun naoPermiteMudarAlternativaDepoisDeConfirmar() {
        val confirmado = novoQuiz().selecionar(3).confirmar()
        val tentativa = confirmado.selecionar(0) // tenta trocar para a correta

        assertSame(confirmado, tentativa) // nada mudou
        assertEquals(3, tentativa.respostaConfirmada)
        assertEquals(false, tentativa.acertouQuestaoAtual)
    }

    @Test
    fun confirmarDuasVezesNaoContaDuasVezes() {
        val umaVez = novoQuiz().selecionar(0).confirmar()
        val duasVezes = umaVez.confirmar().confirmar()

        assertSame(umaVez, duasVezes)
        assertEquals(1, duasVezes.quantidadeRespondidas)
        assertEquals(Resultado(acertos = 1, erros = 0), duasVezes.calcularResultado())
    }

    @Test
    fun naoConfirmaSemAlternativaSelecionada() {
        val inicio = novoQuiz()
        assertFalse(inicio.podeConfirmar)
        assertSame(inicio, inicio.confirmar())
    }

    @Test
    fun naoAvancaSemConfirmarResposta() {
        val selecionado = novoQuiz().selecionar(2)
        assertFalse(selecionado.podeAvancar)
        assertEquals(0, selecionado.avancar().indiceAtual)
    }

    @Test
    fun ignoraAlternativaInexistente() {
        val inicio = novoQuiz()
        assertSame(inicio, inicio.selecionar(5))
        assertSame(inicio, inicio.selecionar(-1))
    }

    // ---------------- Progresso ----------------

    @Test
    fun progressoAcompanhaRespostas() {
        val inicio = novoQuiz()
        assertEquals(1, inicio.numeroQuestao)
        assertEquals(0f, inicio.progresso, 0.0001f)

        val segunda = inicio.responderEAvancar(0)
        assertEquals(2, segunda.numeroQuestao)
        assertNull(segunda.selecionada) // a seleção é limpa ao avançar
        assertEquals(0.25f, segunda.progresso, 0.0001f)
    }

    @Test
    fun ultimaQuestaoFinalizaQuiz() {
        var estado = novoQuiz()
        repeat(3) { estado = estado.responderEAvancar(0) }
        assertTrue(estado.ehUltimaQuestao)
        assertFalse(estado.finalizado)

        estado = estado.responderEAvancar(0)
        assertTrue(estado.finalizado)
        assertEquals(1f, estado.progresso, 0.0001f)
    }

    // ---------------- Reinício ----------------

    @Test
    fun reiniciarZeraTudoEMantemCategoria() {
        var estado = novoQuiz()
        repeat(4) { estado = estado.responderEAvancar(1) }

        val reiniciado = estado.reiniciar()

        assertEquals(Categoria.PROGRAMACAO, reiniciado.categoria)
        assertEquals(0, reiniciado.indiceAtual)
        assertNull(reiniciado.selecionada)
        assertFalse(reiniciado.finalizado)
        assertEquals(0, reiniciado.quantidadeRespondidas)
        assertEquals(Resultado(0, 0), reiniciado.calcularResultado())
        assertEquals(novoQuiz(), reiniciado)
    }

    @Test
    fun voltarParaCategoriasLimpaQuiz() {
        val estado = novoQuiz().selecionar(0).confirmar().voltarParaCategorias()
        assertNull(estado.categoria)
        assertFalse(estado.emAndamento)
    }

    // ---------------- Banco de perguntas ----------------

    @Test
    fun cadaCategoriaTemPeloMenosCincoPerguntasComCincoAlternativas() {
        Categoria.entries.forEach { categoria ->
            val lista = BancoDePerguntas.perguntasDa(categoria)
            assertTrue("${categoria.titulo} tem menos de 5 perguntas", lista.size >= 5)
            lista.forEach { assertEquals(5, it.alternativas.size) }
        }
    }

    @Test(expected = IllegalArgumentException::class)
    fun perguntaComMenosDeCincoAlternativasEhRejeitada() {
        Pergunta("Inválida", listOf("A", "B", "C"), indiceCorreto = 0)
    }
}
